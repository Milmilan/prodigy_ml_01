import React from 'react';
import { Brain, Download } from 'lucide-react';
import { RegressionModel } from '../utils/linearRegression';
import { formatNumber } from '../utils/sampleData';

interface ModelDetailsProps {
  model: RegressionModel;
}

export function ModelDetails({ model }: ModelDetailsProps) {
  const exportModel = () => {
    const modelData = {
      coefficients: model.coefficients,
      intercept: model.intercept,
      metrics: model.metrics,
      equation: `Price = ${formatNumber(model.intercept, 4)} + ${formatNumber(model.coefficients[0], 4)} × sqft + ${formatNumber(model.coefficients[1], 4)} × bedrooms + ${formatNumber(model.coefficients[2], 4)} × bathrooms`,
      timestamp: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(modelData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'house_price_model.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-100 rounded-lg">
            <Brain className="w-6 h-6 text-purple-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Model Details</h2>
        </div>
        <button
          onClick={exportModel}
          className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors duration-200"
        >
          <Download className="w-4 h-4" />
          Export Model
        </button>
      </div>

      <div className="space-y-6">
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Regression Equation</h3>
          <div className="font-mono text-sm bg-white p-4 rounded border border-gray-200 overflow-x-auto">
            <div className="text-blue-600 font-semibold">
              Price = {formatNumber(model.intercept, 2)} + {formatNumber(model.coefficients[0], 2)} × sqft + {formatNumber(model.coefficients[1], 2)} × bedrooms + {formatNumber(model.coefficients[2], 2)} × bathrooms
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-800">Coefficients</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="font-medium text-blue-800">Intercept (β₀)</span>
                <span className="font-mono text-blue-600">{formatNumber(model.intercept, 4)}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="font-medium text-gray-700">Square Footage (β₁)</span>
                <span className="font-mono text-gray-600">{formatNumber(model.coefficients[0], 4)}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="font-medium text-gray-700">Bedrooms (β₂)</span>
                <span className="font-mono text-gray-600">{formatNumber(model.coefficients[1], 4)}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="font-medium text-gray-700">Bathrooms (β₃)</span>
                <span className="font-mono text-gray-600">{formatNumber(model.coefficients[2], 4)}</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-800">Feature Impact</h3>
            <div className="space-y-3">
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium text-green-800">Per Square Foot</span>
                  <span className="font-bold text-green-600">+${formatNumber(model.coefficients[0], 0)}</span>
                </div>
                <p className="text-xs text-green-700">Price increase per sq ft</p>
              </div>
              
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium text-blue-800">Per Bedroom</span>
                  <span className="font-bold text-blue-600">
                    {model.coefficients[1] >= 0 ? '+' : ''}${formatNumber(model.coefficients[1], 0)}
                  </span>
                </div>
                <p className="text-xs text-blue-700">Price change per bedroom</p>
              </div>
              
              <div className="p-3 bg-teal-50 rounded-lg border border-teal-200">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium text-teal-800">Per Bathroom</span>
                  <span className="font-bold text-teal-600">
                    {model.coefficients[2] >= 0 ? '+' : ''}${formatNumber(model.coefficients[2], 0)}
                  </span>
                </div>
                <p className="text-xs text-teal-700">Price change per bathroom</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 border border-purple-200">
          <h3 className="text-lg font-semibold text-purple-800 mb-3">Statistical Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-purple-700 mb-2">
                <strong>Algorithm:</strong> Multiple Linear Regression using Normal Equation
              </p>
              <p className="text-purple-700 mb-2">
                <strong>Features:</strong> Square footage, bedrooms, bathrooms
              </p>
              <p className="text-purple-700">
                <strong>Training Method:</strong> Least squares optimization with feature normalization
              </p>
            </div>
            <div>
              <p className="text-purple-700 mb-2">
                <strong>Model Accuracy:</strong> {performance.level} ({formatNumber(model.metrics.rSquared * 100, 1)}% variance explained)
              </p>
              <p className="text-purple-700 mb-2">
                <strong>Average Error:</strong> ±${formatNumber(model.metrics.mae, 0)}
              </p>
              <p className="text-purple-700">
                <strong>Training Samples:</strong> {data.length} houses
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}