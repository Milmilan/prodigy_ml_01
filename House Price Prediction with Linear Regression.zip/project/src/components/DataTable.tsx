import React, { useState } from 'react';
import { Database, Download, Eye, EyeOff } from 'lucide-react';
import { HouseData } from '../utils/linearRegression';
import { formatPrice, formatNumber } from '../utils/sampleData';

interface DataTableProps {
  data: HouseData[];
  predictions: number[];
}

export function DataTable({ data, predictions }: DataTableProps) {
  const [showAll, setShowAll] = useState(false);
  const [sortField, setSortField] = useState<keyof HouseData | 'prediction' | 'error'>('sqft');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const displayData = showAll ? data : data.slice(0, 10);

  const sortedData = [...displayData].sort((a, b) => {
    let aVal: number, bVal: number;
    
    if (sortField === 'prediction') {
      aVal = predictions[data.indexOf(a)];
      bVal = predictions[data.indexOf(b)];
    } else if (sortField === 'error') {
      aVal = Math.abs(a.price - predictions[data.indexOf(a)]);
      bVal = Math.abs(b.price - predictions[data.indexOf(b)]);
    } else {
      aVal = a[sortField];
      bVal = b[sortField];
    }

    return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
  });

  const handleSort = (field: keyof HouseData | 'prediction' | 'error') => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const exportData = () => {
    const exportData = data.map((house, index) => ({
      ...house,
      prediction: predictions[index],
      error: Math.abs(house.price - predictions[index]),
      errorPercentage: (Math.abs(house.price - predictions[index]) / house.price) * 100,
    }));

    const csv = [
      'Square Footage,Bedrooms,Bathrooms,Actual Price,Predicted Price,Absolute Error,Error %',
      ...exportData.map(row => 
        `${row.sqft},${row.bedrooms},${row.bathrooms},${row.price},${row.prediction.toFixed(0)},${row.error.toFixed(0)},${row.errorPercentage.toFixed(2)}`
      )
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'house_price_predictions.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const SortButton = ({ field, children }: { field: keyof HouseData | 'prediction' | 'error', children: React.ReactNode }) => (
    <button
      onClick={() => handleSort(field)}
      className="flex items-center gap-1 font-semibold text-gray-700 hover:text-blue-600 transition-colors duration-200"
    >
      {children}
      {sortField === field && (
        <span className="text-blue-600">
          {sortDirection === 'asc' ? '↑' : '↓'}
        </span>
      )}
    </button>
  );

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
      <div className="flex items-center justify-between p-6 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-100 rounded-lg">
            <Database className="w-6 h-6 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Training Data & Predictions</h2>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAll(!showAll)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors duration-200"
          >
            {showAll ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {showAll ? 'Show Less' : `Show All (${data.length})`}
          </button>
          <button
            onClick={exportData}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors duration-200"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-4 text-left">
                <SortButton field="sqft">Square Footage</SortButton>
              </th>
              <th className="px-6 py-4 text-left">
                <SortButton field="bedrooms">Bedrooms</SortButton>
              </th>
              <th className="px-6 py-4 text-left">
                <SortButton field="bathrooms">Bathrooms</SortButton>
              </th>
              <th className="px-6 py-4 text-left">
                <SortButton field="price">Actual Price</SortButton>
              </th>
              <th className="px-6 py-4 text-left">
                <SortButton field="prediction">Predicted Price</SortButton>
              </th>
              <th className="px-6 py-4 text-left">
                <SortButton field="error">Error</SortButton>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {sortedData.map((house, index) => {
              const originalIndex = data.indexOf(house);
              const prediction = predictions[originalIndex];
              const error = Math.abs(house.price - prediction);
              const errorPercentage = (error / house.price) * 100;
              
              return (
                <tr key={originalIndex} className="hover:bg-gray-50 transition-colors duration-150">
                  <td className="px-6 py-4 text-gray-900 font-medium">
                    {house.sqft.toLocaleString()} sq ft
                  </td>
                  <td className="px-6 py-4 text-gray-700">{house.bedrooms}</td>
                  <td className="px-6 py-4 text-gray-700">{house.bathrooms}</td>
                  <td className="px-6 py-4 text-gray-900 font-semibold">
                    {formatPrice(house.price)}
                  </td>
                  <td className="px-6 py-4 text-blue-600 font-semibold">
                    {formatPrice(prediction)}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className={`font-semibold ${errorPercentage < 5 ? 'text-green-600' : errorPercentage < 10 ? 'text-yellow-600' : 'text-red-600'}`}>
                        {formatPrice(error)}
                      </span>
                      <span className="text-xs text-gray-500">
                        {formatNumber(errorPercentage, 1)}%
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {!showAll && data.length > 10 && (
        <div className="p-4 text-center border-t border-gray-200 bg-gray-50">
          <p className="text-sm text-gray-600">
            Showing 10 of {data.length} houses. 
            <button 
              onClick={() => setShowAll(true)}
              className="text-blue-600 hover:text-blue-700 font-medium ml-1"
            >
              Show all data
            </button>
          </p>
        </div>
      )}
    </div>
  );
}