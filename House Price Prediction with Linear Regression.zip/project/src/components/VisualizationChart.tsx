import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ScatterController,
} from 'chart.js';
import { Scatter } from 'react-chartjs-2';
import { BarChart3 } from 'lucide-react';
import { HouseData } from '../utils/linearRegression';
import { formatPrice } from '../utils/sampleData';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ScatterController
);

interface VisualizationChartProps {
  data: HouseData[];
  predictions: number[];
}

export function VisualizationChart({ data, predictions }: VisualizationChartProps) {
  const scatterData = {
    datasets: [
      {
        label: 'Actual Prices',
        data: data.map((house, index) => ({
          x: house.sqft,
          y: house.price,
        })),
        backgroundColor: 'rgba(37, 99, 235, 0.6)',
        borderColor: 'rgba(37, 99, 235, 1)',
        borderWidth: 2,
        pointRadius: 6,
        pointHoverRadius: 8,
      },
      {
        label: 'Predicted Prices',
        data: data.map((house, index) => ({
          x: house.sqft,
          y: predictions[index],
        })),
        backgroundColor: 'rgba(234, 88, 12, 0.6)',
        borderColor: 'rgba(234, 88, 12, 1)',
        borderWidth: 2,
        pointRadius: 6,
        pointHoverRadius: 8,
        pointStyle: 'triangle',
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          usePointStyle: true,
          padding: 20,
          font: {
            size: 12,
            weight: '600',
          },
        },
      },
      title: {
        display: true,
        text: 'House Prices vs Square Footage',
        font: {
          size: 16,
          weight: 'bold',
        },
        padding: 20,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const point = context.parsed;
            return `${context.dataset.label}: ${formatPrice(point.y)} (${point.x.toLocaleString()} sq ft)`;
          },
        },
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: 'white',
        bodyColor: 'white',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        borderWidth: 1,
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Square Footage',
          font: {
            size: 14,
            weight: '600',
          },
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          callback: function(value: any) {
            return value.toLocaleString();
          },
        },
      },
      y: {
        title: {
          display: true,
          text: 'Price ($)',
          font: {
            size: 14,
            weight: '600',
          },
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
        ticks: {
          callback: function(value: any) {
            return formatPrice(value);
          },
        },
      },
    },
    interaction: {
      intersect: false,
      mode: 'nearest' as const,
    },
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-orange-100 rounded-lg">
          <BarChart3 className="w-6 h-6 text-orange-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800">Data Visualization</h2>
      </div>

      <div className="h-96 mb-6">
        <Scatter data={scatterData} options={options} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
        <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
          <div className="w-4 h-4 bg-blue-600 rounded-full"></div>
          <span className="text-blue-800 font-medium">Actual house prices from training data</span>
        </div>
        <div className="flex items-center gap-2 p-3 bg-orange-50 rounded-lg">
          <div className="w-4 h-4 bg-orange-600" style={{ clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' }}></div>
          <span className="text-orange-800 font-medium">Model predictions for same houses</span>
        </div>
      </div>
    </div>
  );
}