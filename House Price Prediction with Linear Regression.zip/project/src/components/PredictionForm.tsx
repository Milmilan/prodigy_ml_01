import React, { useState } from 'react';
import { Calculator, Home } from 'lucide-react';
import { formatPrice } from '../utils/sampleData';

interface PredictionFormProps {
  onPredict: (sqft: number, bedrooms: number, bathrooms: number) => number;
}

export function PredictionForm({ onPredict }: PredictionFormProps) {
  const [sqft, setSqft] = useState(1800);
  const [bedrooms, setBedrooms] = useState(3);
  const [bathrooms, setBathrooms] = useState(2);
  const [prediction, setPrediction] = useState<number | null>(null);

  const handlePredict = () => {
    try {
      const result = onPredict(sqft, bedrooms, bathrooms);
      setPrediction(result);
    } catch (error) {
      console.error('Prediction error:', error);
    }
  };

  React.useEffect(() => {
    handlePredict();
  }, [sqft, bedrooms, bathrooms, onPredict]);

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-blue-100 rounded-lg">
          <Calculator className="w-6 h-6 text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800">Price Prediction</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-gray-700">
            Square Footage
          </label>
          <input
            type="number"
            value={sqft}
            onChange={(e) => setSqft(Number(e.target.value))}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            min="500"
            max="5000"
            step="50"
          />
          <p className="text-xs text-gray-500">500 - 5,000 sq ft</p>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-gray-700">
            Bedrooms
          </label>
          <input
            type="number"
            value={bedrooms}
            onChange={(e) => setBedrooms(Number(e.target.value))}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            min="1"
            max="8"
          />
          <p className="text-xs text-gray-500">1 - 8 bedrooms</p>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-gray-700">
            Bathrooms
          </label>
          <input
            type="number"
            value={bathrooms}
            onChange={(e) => setBathrooms(Number(e.target.value))}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            min="1"
            max="6"
            step="0.5"
          />
          <p className="text-xs text-gray-500">1 - 6 bathrooms</p>
        </div>
      </div>

      {prediction !== null && (
        <div className="bg-gradient-to-r from-blue-50 to-teal-50 rounded-xl p-6 border border-blue-200">
          <div className="flex items-center gap-3 mb-3">
            <Home className="w-6 h-6 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-800">Predicted Price</h3>
          </div>
          <div className="text-3xl font-bold text-blue-600 mb-2">
            {formatPrice(prediction)}
          </div>
          <p className="text-sm text-gray-600">
            Based on {sqft.toLocaleString()} sq ft, {bedrooms} bed, {bathrooms} bath
          </p>
        </div>
      )}
    </div>
  );
}