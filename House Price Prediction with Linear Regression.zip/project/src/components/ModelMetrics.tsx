import React from 'react';
import { TrendingUp, Target, AlertCircle, CheckCircle } from 'lucide-react';
import { ModelMetrics } from '../utils/linearRegression';
import { formatNumber } from '../utils/sampleData';

interface ModelMetricsProps {
  metrics: ModelMetrics;
}

export function ModelMetricsComponent({ metrics }: ModelMetricsProps) {
  const getPerformanceLevel = (rSquared: number) => {
    if (rSquared >= 0.9) return { level: 'Excellent', color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle };
    if (rSquared >= 0.8) return { level: 'Good', color: 'text-blue-600', bg: 'bg-blue-50', icon: TrendingUp };
    if (rSquared >= 0.7) return { level: 'Fair', color: 'text-yellow-600', bg: 'bg-yellow-50', icon: Target };
    return { level: 'Poor', color: 'text-red-600', bg: 'bg-red-50', icon: AlertCircle };
  };

  const performance = getPerformanceLevel(metrics.rSquared);
  const Icon = performance.icon;

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-teal-100 rounded-lg">
          <TrendingUp className="w-6 h-6 text-teal-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800">Model Performance</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className={`${performance.bg} rounded-lg p-6 border border-opacity-20`}>
          <div className="flex items-center gap-2 mb-2">
            <Icon className={`w-5 h-5 ${performance.color}`} />
            <h3 className="font-semibold text-gray-700">R-Squared</h3>
          </div>
          <div className={`text-2xl font-bold ${performance.color} mb-1`}>
            {formatNumber(metrics.rSquared * 100, 1)}%
          </div>
          <p className={`text-sm ${performance.color} font-medium`}>
            {performance.level}
          </p>
          <p className="text-xs text-gray-600 mt-2">
            Variance explained by model
          </p>
        </div>

        <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
          <h3 className="font-semibold text-gray-700 mb-2">RMSE</h3>
          <div className="text-2xl font-bold text-gray-800 mb-1">
            ${formatNumber(metrics.rmse, 0)}
          </div>
          <p className="text-xs text-gray-600">
            Root Mean Squared Error
          </p>
        </div>

        <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
          <h3 className="font-semibold text-gray-700 mb-2">MAE</h3>
          <div className="text-2xl font-bold text-gray-800 mb-1">
            ${formatNumber(metrics.mae, 0)}
          </div>
          <p className="text-xs text-gray-600">
            Mean Absolute Error
          </p>
        </div>

        <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
          <h3 className="font-semibold text-gray-700 mb-2">MSE</h3>
          <div className="text-2xl font-bold text-gray-800 mb-1">
            {formatNumber(metrics.mse, 0)}
          </div>
          <p className="text-xs text-gray-600">
            Mean Squared Error
          </p>
        </div>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <h4 className="font-semibold text-blue-800 mb-2">Model Interpretation</h4>
        <p className="text-sm text-blue-700">
          The model explains <strong>{formatNumber(metrics.rSquared * 100, 1)}%</strong> of the variance in house prices.
          On average, predictions are within <strong>${formatNumber(metrics.mae, 0)}</strong> of actual prices.
          {metrics.rSquared >= 0.8 && " This indicates a strong predictive relationship."}
          {metrics.rSquared < 0.8 && metrics.rSquared >= 0.6 && " This shows a moderate predictive relationship."}
          {metrics.rSquared < 0.6 && " Consider adding more features to improve accuracy."}
        </p>
      </div>
    </div>
  );
}