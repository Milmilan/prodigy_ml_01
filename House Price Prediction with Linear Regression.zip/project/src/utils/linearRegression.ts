export interface HouseData {
  sqft: number;
  bedrooms: number;
  bathrooms: number;
  price: number;
}

export interface ModelMetrics {
  rSquared: number;
  mse: number;
  mae: number;
  rmse: number;
}

export interface RegressionModel {
  coefficients: number[];
  intercept: number;
  metrics: ModelMetrics;
}

export class LinearRegression {
  private model: RegressionModel | null = null;
  private featureMeans: number[] = [];
  private featureStds: number[] = [];
  private targetMean: number = 0;
  private targetStd: number = 1;

  // Normalize features for better convergence
  private normalizeFeatures(X: number[][]): number[][] {
    const numFeatures = X[0].length;
    this.featureMeans = [];
    this.featureStds = [];

    for (let j = 0; j < numFeatures; j++) {
      const column = X.map(row => row[j]);
      const mean = column.reduce((sum, val) => sum + val, 0) / column.length;
      const variance = column.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / column.length;
      const std = Math.sqrt(variance);
      
      this.featureMeans.push(mean);
      this.featureStds.push(std || 1); // Avoid division by zero
    }

    return X.map(row => 
      row.map((val, j) => (val - this.featureMeans[j]) / this.featureStds[j])
    );
  }

  private normalizeTarget(y: number[]): number[] {
    this.targetMean = y.reduce((sum, val) => sum + val, 0) / y.length;
    const variance = y.reduce((sum, val) => sum + Math.pow(val - this.targetMean, 2), 0) / y.length;
    this.targetStd = Math.sqrt(variance);
    
    return y.map(val => (val - this.targetMean) / this.targetStd);
  }

  private denormalizeTarget(normalizedPrice: number): number {
    return normalizedPrice * this.targetStd + this.targetMean;
  }

  // Matrix operations
  private transpose(matrix: number[][]): number[][] {
    return matrix[0].map((_, colIndex) => matrix.map(row => row[colIndex]));
  }

  private multiply(A: number[][], B: number[][]): number[][] {
    const result: number[][] = [];
    for (let i = 0; i < A.length; i++) {
      result[i] = [];
      for (let j = 0; j < B[0].length; j++) {
        let sum = 0;
        for (let k = 0; k < B.length; k++) {
          sum += A[i][k] * B[k][j];
        }
        result[i][j] = sum;
      }
    }
    return result;
  }

  private inverse(matrix: number[][]): number[][] {
    const n = matrix.length;
    const identity = Array(n).fill(0).map((_, i) => 
      Array(n).fill(0).map((_, j) => i === j ? 1 : 0)
    );
    
    const augmented = matrix.map((row, i) => [...row, ...identity[i]]);
    
    // Gaussian elimination
    for (let i = 0; i < n; i++) {
      // Find pivot
      let maxRow = i;
      for (let k = i + 1; k < n; k++) {
        if (Math.abs(augmented[k][i]) > Math.abs(augmented[maxRow][i])) {
          maxRow = k;
        }
      }
      [augmented[i], augmented[maxRow]] = [augmented[maxRow], augmented[i]];
      
      // Make diagonal 1
      const pivot = augmented[i][i];
      for (let j = 0; j < 2 * n; j++) {
        augmented[i][j] /= pivot;
      }
      
      // Eliminate column
      for (let k = 0; k < n; k++) {
        if (k !== i) {
          const factor = augmented[k][i];
          for (let j = 0; j < 2 * n; j++) {
            augmented[k][j] -= factor * augmented[i][j];
          }
        }
      }
    }
    
    return augmented.map(row => row.slice(n));
  }

  fit(data: HouseData[]): void {
    // Prepare features and target
    const X = data.map(d => [d.sqft, d.bedrooms, d.bathrooms]);
    const y = data.map(d => d.price);

    // Normalize data
    const X_norm = this.normalizeFeatures(X);
    const y_norm = this.normalizeTarget(y);

    // Add bias term (intercept)
    const X_with_bias = X_norm.map(row => [1, ...row]);

    // Normal equation: θ = (X^T * X)^(-1) * X^T * y
    const X_T = this.transpose(X_with_bias);
    const X_T_X = this.multiply(X_T, X_with_bias);
    const X_T_X_inv = this.inverse(X_T_X);
    const X_T_y = this.multiply(X_T, y_norm.map(val => [val]));
    const theta = this.multiply(X_T_X_inv, X_T_y);

    // Extract coefficients
    const intercept = theta[0][0];
    const coefficients = theta.slice(1).map(row => row[0]);

    // Calculate metrics
    const predictions = X_norm.map(row => {
      const normalizedPred = intercept + coefficients.reduce((sum, coef, i) => sum + coef * row[i], 0);
      return this.denormalizeTarget(normalizedPred);
    });

    const metrics = this.calculateMetrics(y, predictions);

    this.model = {
      coefficients,
      intercept,
      metrics
    };
  }

  predict(sqft: number, bedrooms: number, bathrooms: number): number {
    if (!this.model) {
      throw new Error('Model not trained yet');
    }

    // Normalize input features
    const normalizedFeatures = [
      (sqft - this.featureMeans[0]) / this.featureStds[0],
      (bedrooms - this.featureMeans[1]) / this.featureStds[1],
      (bathrooms - this.featureMeans[2]) / this.featureStds[2]
    ];

    // Calculate normalized prediction
    const normalizedPrediction = this.model.intercept + 
      this.model.coefficients.reduce((sum, coef, i) => sum + coef * normalizedFeatures[i], 0);

    // Denormalize and return
    return this.denormalizeTarget(normalizedPrediction);
  }

  private calculateMetrics(actual: number[], predicted: number[]): ModelMetrics {
    const n = actual.length;
    const actualMean = actual.reduce((sum, val) => sum + val, 0) / n;

    // Mean Squared Error
    const mse = actual.reduce((sum, val, i) => sum + Math.pow(val - predicted[i], 2), 0) / n;
    
    // Mean Absolute Error
    const mae = actual.reduce((sum, val, i) => sum + Math.abs(val - predicted[i]), 0) / n;
    
    // R-squared
    const totalSumSquares = actual.reduce((sum, val) => sum + Math.pow(val - actualMean, 2), 0);
    const residualSumSquares = actual.reduce((sum, val, i) => sum + Math.pow(val - predicted[i], 2), 0);
    const rSquared = 1 - (residualSumSquares / totalSumSquares);

    // Root Mean Squared Error
    const rmse = Math.sqrt(mse);

    return { rSquared, mse, mae, rmse };
  }

  getModel(): RegressionModel | null {
    return this.model;
  }

  getPredictions(data: HouseData[]): number[] {
    if (!this.model) return [];
    return data.map(d => this.predict(d.sqft, d.bedrooms, d.bathrooms));
  }
}