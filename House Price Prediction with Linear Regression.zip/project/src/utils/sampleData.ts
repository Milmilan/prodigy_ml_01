import { HouseData } from './linearRegression';

export const sampleHouseData: HouseData[] = [
  { sqft: 1200, bedrooms: 2, bathrooms: 1, price: 250000 },
  { sqft: 1500, bedrooms: 3, bathrooms: 2, price: 320000 },
  { sqft: 1800, bedrooms: 3, bathrooms: 2, price: 380000 },
  { sqft: 2200, bedrooms: 4, bathrooms: 3, price: 450000 },
  { sqft: 2500, bedrooms: 4, bathrooms: 3, price: 520000 },
  { sqft: 1000, bedrooms: 2, bathrooms: 1, price: 200000 },
  { sqft: 1350, bedrooms: 2, bathrooms: 2, price: 285000 },
  { sqft: 1650, bedrooms: 3, bathrooms: 2, price: 350000 },
  { sqft: 1950, bedrooms: 3, bathrooms: 2, price: 410000 },
  { sqft: 2300, bedrooms: 4, bathrooms: 3, price: 480000 },
  { sqft: 2700, bedrooms: 5, bathrooms: 4, price: 580000 },
  { sqft: 1100, bedrooms: 2, bathrooms: 1, price: 230000 },
  { sqft: 1400, bedrooms: 3, bathrooms: 1, price: 300000 },
  { sqft: 1700, bedrooms: 3, bathrooms: 2, price: 365000 },
  { sqft: 2000, bedrooms: 4, bathrooms: 2, price: 425000 },
  { sqft: 2400, bedrooms: 4, bathrooms: 3, price: 500000 },
  { sqft: 2800, bedrooms: 5, bathrooms: 4, price: 620000 },
  { sqft: 1250, bedrooms: 2, bathrooms: 1, price: 265000 },
  { sqft: 1550, bedrooms: 3, bathrooms: 2, price: 335000 },
  { sqft: 1850, bedrooms: 3, bathrooms: 2, price: 395000 },
  { sqft: 2150, bedrooms: 4, bathrooms: 3, price: 465000 },
  { sqft: 2450, bedrooms: 4, bathrooms: 3, price: 535000 },
  { sqft: 2750, bedrooms: 5, bathrooms: 4, price: 605000 },
  { sqft: 1300, bedrooms: 2, bathrooms: 2, price: 275000 },
  { sqft: 1600, bedrooms: 3, bathrooms: 2, price: 340000 },
  { sqft: 1900, bedrooms: 3, bathrooms: 3, price: 405000 },
  { sqft: 2250, bedrooms: 4, bathrooms: 3, price: 475000 },
  { sqft: 2550, bedrooms: 4, bathrooms: 3, price: 545000 },
  { sqft: 2850, bedrooms: 5, bathrooms: 4, price: 635000 },
  { sqft: 1150, bedrooms: 2, bathrooms: 1, price: 240000 },
  { sqft: 1450, bedrooms: 3, bathrooms: 2, price: 315000 },
  { sqft: 1750, bedrooms: 3, bathrooms: 2, price: 375000 },
  { sqft: 2050, bedrooms: 4, bathrooms: 2, price: 435000 },
  { sqft: 2350, bedrooms: 4, bathrooms: 3, price: 505000 },
  { sqft: 2650, bedrooms: 5, bathrooms: 3, price: 575000 },
  { sqft: 3000, bedrooms: 5, bathrooms: 4, price: 650000 },
  { sqft: 1320, bedrooms: 2, bathrooms: 2, price: 290000 },
  { sqft: 1620, bedrooms: 3, bathrooms: 2, price: 355000 },
  { sqft: 1920, bedrooms: 3, bathrooms: 3, price: 415000 },
  { sqft: 2220, bedrooms: 4, bathrooms: 3, price: 485000 },
  { sqft: 2520, bedrooms: 4, bathrooms: 3, price: 555000 },
  { sqft: 2820, bedrooms: 5, bathrooms: 4, price: 625000 },
  { sqft: 1080, bedrooms: 2, bathrooms: 1, price: 225000 },
  { sqft: 1380, bedrooms: 2, bathrooms: 2, price: 295000 },
  { sqft: 1680, bedrooms: 3, bathrooms: 2, price: 360000 },
  { sqft: 1980, bedrooms: 3, bathrooms: 3, price: 420000 },
  { sqft: 2280, bedrooms: 4, bathrooms: 3, price: 490000 },
  { sqft: 2580, bedrooms: 4, bathrooms: 3, price: 560000 },
  { sqft: 2880, bedrooms: 5, bathrooms: 4, price: 630000 },
  { sqft: 1180, bedrooms: 2, bathrooms: 1, price: 245000 },
  { sqft: 1480, bedrooms: 3, bathrooms: 2, price: 325000 },
  { sqft: 1780, bedrooms: 3, bathrooms: 2, price: 385000 }
];

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price);
}

export function formatNumber(num: number, decimals: number = 2): string {
  return num.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}