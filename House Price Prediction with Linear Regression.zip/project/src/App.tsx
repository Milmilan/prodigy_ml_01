import React, { useState, useEffect } from 'react';
import { Home, TrendingUp, Database, Brain } from 'lucide-react';
import { LinearRegression, RegressionModel } from './utils/linearRegression';
import { sampleHouseData } from './utils/sampleData';
import { PredictionForm } from './components/PredictionForm';
import { ModelMetricsComponent } from './components/ModelMetrics';
import { VisualizationChart } from './components/VisualizationChart';
import { ModelDetails } from './components/ModelDetails';
import { DataTable } from './components/DataTable';

function App() {
  const [model, setModel] = useState<LinearRegression | null>(null);
  const [modelData, setModelData] = useState<RegressionModel | null>(null);
  const [predictions, setPredictions] = useState<number[]>([]);
  const [isTraining, setIsTraining] = useState(true);

  useEffect(() => {
    // Train the model
    const regression = new LinearRegression();
    
    setTimeout(() => {
      regression.fit(sampleHouseData);
      const trainedModel = regression.getModel();
      const modelPredictions = regression.getPredictions(sampleHouseData);
      
      setModel(regression);
      setModelData(trainedModel);
      setPredictions(modelPredictions);
      setIsTraining(false);
    }, 1000); // Simulate training time
  }, []);

  const handlePredict = (sqft: number, bedrooms: number, bathrooms: number): number => {
    if (!model) return 0;
    return model.predict(sqft, bedrooms, bathrooms);
  };

  if (isTraining) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Training Linear Regression Model</h2>
          <p className="text-gray-600">Analyzing house price patterns...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-600 rounded-xl">
              <Home className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">House Price Prediction</h1>
              <p className="text-gray-600 mt-1">Multiple Linear Regression Analysis</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
            <div className="flex items-center gap-3">
              <Database className="w-8 h-8 text-blue-600" />
              <div>
                <p className="text-2xl font-bold text-gray-900">{sampleHouseData.length}</p>
                <p className="text-sm text-gray-600">Training Samples</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
            <div className="flex items-center gap-3">
              <Brain className="w-8 h-8 text-teal-600" />
              <div>
                <p className="text-2xl font-bold text-gray-900">3</p>
                <p className="text-sm text-gray-600">Features</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-8 h-8 text-green-600" />
              <div>
                <p className="text-2xl font-bold text-gray-900">
                  {modelData ? `${(modelData.metrics.rSquared * 100).toFixed(1)}%` : '0%'}
                </p>
                <p className="text-sm text-gray-600">R-Squared</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
            <div className="flex items-center gap-3">
              <Home className="w-8 h-8 text-purple-600" />
              <div>
                <p className="text-2xl font-bold text-gray-900">
                  {modelData ? `$${(modelData.metrics.mae / 1000).toFixed(0)}K` : '$0'}
                </p>
                <p className="text-sm text-gray-600">Avg Error</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="space-y-8">
          {/* Prediction Form */}
          <PredictionForm onPredict={handlePredict} />

          {/* Model Metrics */}
          {modelData && <ModelMetricsComponent metrics={modelData.metrics} />}

          {/* Visualization */}
          <VisualizationChart data={sampleHouseData} predictions={predictions} />

          {/* Model Details */}
          {modelData && <ModelDetails model={modelData} />}

          {/* Data Table */}
          <DataTable data={sampleHouseData} predictions={predictions} />
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center">
            <p className="text-gray-600">
              Linear Regression Implementation • Built with React & TypeScript
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Professional internship project demonstrating machine learning fundamentals
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;